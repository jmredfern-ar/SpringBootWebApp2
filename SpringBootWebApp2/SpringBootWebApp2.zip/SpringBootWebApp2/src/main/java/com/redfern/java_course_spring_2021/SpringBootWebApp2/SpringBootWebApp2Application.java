package com.redfern.java_course_spring_2021.SpringBootWebApp2;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class SpringBootWebApp2Application {

	public static void main(String[] args) {
		SpringApplication.run(SpringBootWebApp2Application.class, args);
	}

}
