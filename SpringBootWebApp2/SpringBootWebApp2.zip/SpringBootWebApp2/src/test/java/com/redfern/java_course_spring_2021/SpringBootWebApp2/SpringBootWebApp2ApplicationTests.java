package com.redfern.java_course_spring_2021.SpringBootWebApp2;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootWebApp2ApplicationTests {

	@Test
	void contextLoads() {
	}

}
